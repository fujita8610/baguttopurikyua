#pragma once
#include "DxLib.h"

// �֐��̃v���g�^�C�v�錾
void InitTitleScene();
void LoadTitleScene();
void StartTitleScene();
void StepTitleScene();
void UpdateTitleScene();
void DrawTitleScene();
void FinTitleScene();
