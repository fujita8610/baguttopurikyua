#pragma once

// �֐��̃v���g�^�C�v�錾
void InitOptionScene();
void LoadOptionScene();
void StartOptionScene();
void StepOptionScene();
void UpdateOptionScene();
void DrawOptionScene();
void FinOptionScene();
